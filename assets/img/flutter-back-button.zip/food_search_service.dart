// Flutter service to search foods from Firebase
import 'package:cloud_firestore/cloud_firestore.dart';

class FoodSearchService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  
  // Search foods by name
  Future<List<Map<String, dynamic>>> searchFoodsByName(String query) async {
    try {
      // Convert query to lowercase for case-insensitive search
      String searchQuery = query.toLowerCase();
      
      // Search by name (you might want to implement full-text search)
      QuerySnapshot snapshot = await _firestore
          .collection('foods')
          .where('name', isGreaterThanOrEqualTo: searchQuery)
          .where('name', isLessThan: searchQuery + 'z')
          .limit(20)
          .get();
      
      return snapshot.docs.map((doc) {
        Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
        data['id'] = doc.id;
        return data;
      }).toList();
    } catch (e) {
      print('Error searching foods: $e');
      return [];
    }
  }
  
  // Get foods by category
  Future<List<Map<String, dynamic>>> getFoodsByCategory(String category) async {
    try {
      QuerySnapshot snapshot = await _firestore
          .collection('foods')
          .where('category', isEqualTo: category)
          .orderBy('name')
          .get();
      
      return snapshot.docs.map((doc) {
        Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
        data['id'] = doc.id;
        return data;
      }).toList();
    } catch (e) {
      print('Error getting foods by category: $e');
      return [];
    }
  }
  
  // Get common foods (most used)
  Future<List<Map<String, dynamic>>> getCommonFoods() async {
    try {
      QuerySnapshot snapshot = await _firestore
          .collection('foods')
          .where('common', isEqualTo: true)
          .orderBy('name')
          .get();
      
      return snapshot.docs.map((doc) {
        Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
        data['id'] = doc.id;
        return data;
      }).toList();
    } catch (e) {
      print('Error getting common foods: $e');
      return [];
    }
  }
  
  // Get food by ID
  Future<Map<String, dynamic>?> getFoodById(String foodId) async {
    try {
      DocumentSnapshot doc = await _firestore
          .collection('foods')
          .doc(foodId)
          .get();
      
      if (doc.exists) {
        Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
        data['id'] = doc.id;
        return data;
      }
      return null;
    } catch (e) {
      print('Error getting food by ID: $e');
      return null;
    }
  }
  
  // Advanced search with filters
  Future<List<Map<String, dynamic>>> advancedFoodSearch({
    String? query,
    String? category,
    String? subcategory,
    bool? commonOnly,
    int? maxCalories,
    int? minProtein,
  }) async {
    try {
      Query queryRef = _firestore.collection('foods');
      
      if (category != null) {
        queryRef = queryRef.where('category', isEqualTo: category);
      }
      
      if (subcategory != null) {
        queryRef = queryRef.where('subcategory', isEqualTo: subcategory);
      }
      
      if (commonOnly == true) {
        queryRef = queryRef.where('common', isEqualTo: true);
      }
      
      if (maxCalories != null) {
        queryRef = queryRef.where('calories', isLessThanOrEqualTo: maxCalories);
      }
      
      if (minProtein != null) {
        queryRef = queryRef.where('protein', isGreaterThanOrEqualTo: minProtein);
      }
      
      QuerySnapshot snapshot = await queryRef.limit(50).get();
      
      List<Map<String, dynamic>> results = snapshot.docs.map((doc) {
        Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
        data['id'] = doc.id;
        return data;
      }).toList();
      
      // If query is provided, filter by name locally
      if (query != null && query.isNotEmpty) {
        String searchQuery = query.toLowerCase();
        results = results.where((food) {
          return food['name'].toString().toLowerCase().contains(searchQuery);
        }).toList();
      }
      
      return results;
    } catch (e) {
      print('Error in advanced search: $e');
      return [];
    }
  }
}
