import 'package:flutter/material.dart';
import 'package:trenpal/gradiant_back.dart'; // Import your gradient

class KeyboardSafeWrapper extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry? padding;
  final bool enableScrolling;
  final MainAxisAlignment mainAxisAlignment;
  final CrossAxisAlignment crossAxisAlignment;
  final bool useGradientBackground;
  final double topSpacing;
  final double bottomSpacing;
  final bool enableTopSafeArea;
  final bool enableBottomSafeArea;

  const KeyboardSafeWrapper({
    super.key,
    required this.child,
    this.padding,
    this.enableScrolling = true,
    this.mainAxisAlignment = MainAxisAlignment.start,
    this.crossAxisAlignment = CrossAxisAlignment.center,
    this.useGradientBackground = true,
    this.topSpacing = 0.0,
    this.bottomSpacing = 0.0,
    this.enableTopSafeArea = false,
    this.enableBottomSafeArea = true,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      body: Stack(
        children: [
          // Gradient background
          if (useGradientBackground) const GradientBack(),
          // Content with keyboard handling
          SafeArea(
            top: enableTopSafeArea,
            bottom: enableBottomSafeArea,
            child: enableScrolling
                ? SingleChildScrollView(
                    padding: padding ?? EdgeInsets.zero,
                    physics: const ClampingScrollPhysics(),
                    child: ConstrainedBox(
                      constraints: BoxConstraints(
                        minHeight: MediaQuery.of(context).size.height -
                            (enableTopSafeArea ? MediaQuery.of(context).padding.top : 0) -
                            (enableBottomSafeArea ? MediaQuery.of(context).padding.bottom : 0),
                      ),
                      child: Column(
                        mainAxisAlignment: mainAxisAlignment,
                        crossAxisAlignment: crossAxisAlignment,
                        children: [
                          SizedBox(height: topSpacing),
                          Expanded(
                            child: child,
                          ),
                          SizedBox(height: bottomSpacing),
                        ],
                      ),
                    ),
                  )
                : Padding(
                    padding: padding ?? EdgeInsets.zero,
                    child: Column(
                      mainAxisAlignment: mainAxisAlignment,
                      crossAxisAlignment: crossAxisAlignment,
                      children: [
                        SizedBox(height: topSpacing),
                        Expanded(
                          child: child,
                        ),
                        SizedBox(height: bottomSpacing),
                      ],
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}
