// Script to upload the food database to Firebase Firestore
// Run this in Node.js environment with Firebase Admin SDK

const admin = require("firebase-admin")
const fs = require("fs")

// Initialize Firebase Admin SDK
// Replace with your service account key path
const serviceAccount = require("./path-to-your-service-account-key.json")

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  // Replace with your project ID
  projectId: "your-project-id",
})

const db = admin.firestore()

async function uploadFoodsToFirestore() {
  try {
    // Read the JSON file
    const foodsData = JSON.parse(fs.readFileSync("./foods_database.json", "utf8"))

    console.log(`Starting upload of ${foodsData.length} foods...`)

    // Create a batch for efficient uploads
    const batch = db.batch()

    foodsData.forEach((food, index) => {
      const docRef = db.collection("foods").doc(food.id.toString())
      batch.set(docRef, {
        ...food,
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      })

      // Firebase batch has a limit of 500 operations
      if ((index + 1) % 500 === 0) {
        console.log(`Prepared ${index + 1} foods for upload...`)
      }
    })

    // Commit the batch
    await batch.commit()
    console.log("Successfully uploaded all foods to Firestore!")

    // Create indexes for better search performance
    console.log("Creating search indexes...")

    // You might want to create composite indexes in Firebase Console for:
    // - category + name
    // - subcategory + name
    // - common + name
    // - name (for text search)

    console.log("Upload completed successfully!")
  } catch (error) {
    console.error("Error uploading foods:", error)
  }
}

// Run the upload
uploadFoodsToFirestore()
