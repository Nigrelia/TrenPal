import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:trenpal/custom%20widgets/macros_tracker.dart';
import 'package:trenpal/custom%20widgets/safe_v2.dart';
import 'package:trenpal/custom%20widgets/ten_bot_nav.dart';
import 'package:trenpal/custom%20widgets/tren_alerts.dart';
import 'package:trenpal/custom%20widgets/tren_button.dart';
import '../custom widgets/calories_tracker.dart';
import '../custom widgets/tren_popup.dart';
import 'main_screen.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

class TrenDashboard extends StatefulWidget {
  const TrenDashboard({super.key});

  @override
  State<TrenDashboard> createState() => _TrenDashboardState();
}

class _TrenDashboardState extends State<TrenDashboard> {
  int calorieGoal = 2000;
  int calories = 0;
  int carbs = 0, protein = 0, fats = 0;
  int carbsGoal = 300, proteinGoal = 150, fatsGoal = 70;
  int _currentIndex = 0;
  bool isLoading = true;

  // Fixed logout confirmation dialog
  Future<bool> _showLogoutConfirmation() async {
    final result = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: const Color(0xFF2A2A2A),
          title: const Text(
            'Logout Confirmation',
            style: TextStyle(color: Colors.white),
          ),
          content: const Text(
            'Are you sure you want to logout?',
            style: TextStyle(color: Colors.white70),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text(
                'Cancel',
                style: TextStyle(color: Colors.grey),
              ),
            ),
            TextButton(
              onPressed: () async {
                Navigator.of(context).pop(true);
                await _performLogout();
              },
              child: const Text(
                'Logout',
                style: TextStyle(color: Colors.redAccent),
              ),
            ),
          ],
        );
      },
    );
    return result ?? false;
  }

  // Fixed logout method with proper navigation
  Future<void> _performLogout() async {
    try {
      await FirebaseAuth.instance.signOut();
      if (mounted) {
        // Use pushAndRemoveUntil to clear the navigation stack
        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (context) => const MainScreen()),
          (Route<dynamic> route) => false,
        );
      }
    } catch (e) {
      print("Error during logout: $e");
      if (mounted) {
        TrenAlerts.error(context, "Failed to logout. Please try again.");
      }
    }
  }

  Future<void> changeGoal(String userId, int newGoal) async {
    try {
      final userDoc = FirebaseFirestore.instance
          .collection('users')
          .doc(userId);
      await userDoc.update({"intake": newGoal});
      setState(() {
        calorieGoal = newGoal;
      });
      TrenAlerts.success(context, "Goal Updated!");
    } catch (e) {
      print("Error updating goal: $e");
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Failed to update calorie goal'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  void showTrenPalPopup(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => TrenPalPopup(
        title: 'Set Calorie Goal',
        buttonText: 'Update Goal',
        onSubmit: (value) async {
          await changeGoal(FirebaseAuth.instance.currentUser!.uid, value);
        },
        initialValue: calorieGoal,
        minValue: 1000,
        maxValue: 5000,
        step: 50,
      ),
    );
  }

  void showFastLogPopup(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => TrenPalPopup(
        title: 'Quick Calorie Log',
        buttonText: 'Add Calories',
        onSubmit: (value) async {
          await addCalories(FirebaseAuth.instance.currentUser!.uid, value);
        },
        initialValue: 0,
        minValue: 0,
        maxValue: 2000,
        step: 10,
      ),
    );
  }

  Future<void> addCalories(String userId, int additionalCalories) async {
    try {
      final userDoc = FirebaseFirestore.instance
          .collection('users')
          .doc(userId);
      final newTotal = calories + additionalCalories;
      await userDoc.update({"currentIntake": newTotal});
      setState(() {
        calories = newTotal;
      });
      TrenAlerts.success(context, "Calories Added");
    } catch (e) {
      print("Error adding calories: $e");
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Failed to add calories'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  // Pass the addCalories method to FoodsPage
  List<Widget> get _pages => [
    CaloriesTrackerPage(
      calories: calories,
      calorieGoal: calorieGoal,
      carbs: carbs,
      protein: protein,
      fats: fats,
      carbsGoal: carbsGoal,
      proteinGoal: proteinGoal,
      fatsGoal: fatsGoal,
      onChangeGoal: () => showTrenPalPopup(context),
      onFastLog: () => showFastLogPopup(context),
    ),
    FoodsPage(
      onAddCalories: (calories) async {
        await addCalories(FirebaseAuth.instance.currentUser!.uid, calories);
      },
    ),
    const AICoachPage(),
  ];

  @override
  void initState() {
    super.initState();
    getCalories();
  }

  Future<void> getCalories() async {
    try {
      String uid = FirebaseAuth.instance.currentUser!.uid;
      DocumentSnapshot userDoc = await FirebaseFirestore.instance
          .collection("users")
          .doc(uid)
          .get();
      if (userDoc.exists) {
        final data = userDoc.data() as Map<String, dynamic>;
        setState(() {
          carbs = int.tryParse(data['carbs']?.toString() ?? '0') ?? 0;
          protein = int.tryParse(data['protein']?.toString() ?? '0') ?? 0;
          fats = int.tryParse(data['fats']?.toString() ?? '0') ?? 0;
          calorieGoal =
              int.tryParse(data['intake']?.toString() ?? '2000') ?? 2000;
          calories =
              int.tryParse(data['currentIntake']?.toString() ?? '0') ?? 0;
          isLoading = false;
        });
      } else {
        setState(() {
          isLoading = false;
        });
      }
    } catch (e) {
      print("Error getting calories: $e");
      setState(() => isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return const Scaffold(
        backgroundColor: Color(0xFF1A1A1A),
        body: Center(child: CircularProgressIndicator(color: Colors.redAccent)),
      );
    }

    return PopScope(
      canPop: false,
      onPopInvoked: (bool didPop) async {
        if (!didPop) {
          await _showLogoutConfirmation();
        }
      },
      child: Scaffold(
        backgroundColor: const Color(0xFF1A1A1A),
        body: SafeV2(child: _pages[_currentIndex]),
        bottomNavigationBar: TrenPalBottomNav(
          currentIndex: _currentIndex,
          onTap: (index) {
            setState(() {
              _currentIndex = index;
            });
          },
          items: [
            BottomNavItem(
              label: 'Calories',
              icon: Icons.local_fire_department_rounded,
              badgeCount: 0,
            ),
            BottomNavItem(
              label: 'Foods',
              icon: Icons.fastfood_rounded,
              badgeCount: 0,
            ),
            BottomNavItem(
              label: 'AI Coach',
              icon: Icons.auto_awesome_rounded,
              badgeCount: 0,
            ),
          ],
          activeColor: Colors.redAccent,
        ),
      ),
    );
  }
}

class CaloriesTrackerPage extends StatelessWidget {
  final int calories;
  final int calorieGoal;
  final int carbs;
  final int protein;
  final int fats;
  final int carbsGoal;
  final int proteinGoal;
  final int fatsGoal;
  final VoidCallback onChangeGoal;
  final VoidCallback onFastLog;

  const CaloriesTrackerPage({
    super.key,
    required this.calories,
    required this.calorieGoal,
    required this.carbs,
    required this.protein,
    required this.fats,
    required this.carbsGoal,
    required this.proteinGoal,
    required this.fatsGoal,
    required this.onChangeGoal,
    required this.onFastLog,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          const SizedBox(height: 50),
          Image.asset("assets/img/dashboard1logo.png", height: 80, width: 400),
          const SizedBox(height: 5),
          TrenTracker(
            width: 365,
            height: 356,
            calories: calories,
            calorieGoal: calorieGoal,
          ),
          const SizedBox(height: 20),
          MacrosTracker(
            width: 365,
            height: 200,
            carbs: carbs,
            protein: protein,
            fats: fats,
            carbsGoal: carbsGoal,
            proteinGoal: proteinGoal,
            fatsGoal: fatsGoal,
          ),
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TrenPalButton(
                width: 172,
                height: 50,
                showLoading: false,
                text: "Adjust Intake",
                onPressed: () async {
                  onChangeGoal();
                },
              ),
              const SizedBox(width: 10),
              TrenPalButton(
                width: 172,
                height: 50,
                showLoading: false,
                text: "Quick Add",
                onPressed: () async {
                  onFastLog();
                },
              ),
            ],
          ),
          const SizedBox(height: 50),
        ],
      ),
    );
  }
}

class FoodsPage extends StatefulWidget {
  final Function(int) onAddCalories;
  
  const FoodsPage({super.key, required this.onAddCalories});

  @override
  State<FoodsPage> createState() => _FoodsPageState();
}

class _FoodsPageState extends State<FoodsPage> {
  final TextEditingController _searchController = TextEditingController();
  List<dynamic> _foods = [];
  bool _isLoading = false;

  Future<void> searchFoods(String query) async {
    if (query.trim().isEmpty) {
      setState(() => _foods = []);
      return;
    }

    setState(() => _isLoading = true);
    
    final url = Uri.parse(
      "https://world.openfoodfacts.org/cgi/search.pl?search_terms=${Uri.encodeComponent(query)}&search_simple=1&action=process&json=1&page_size=20",
    );
    
    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          _foods = data['products'] ?? [];
        });
      } else {
        setState(() => _foods = []);
      }
    } catch (e) {
      print("Error fetching foods: $e");
      setState(() => _foods = []);
      if (mounted) {
        TrenAlerts.error(context, "Failed to search foods. Please try again.");
      }
    }
    
    setState(() => _isLoading = false);
  }

  void _showGramPopup(dynamic food) {
    final gramController = TextEditingController();
    
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF2A2A2A),
        title: Text(
          food['product_name'] ?? "Add Food",
          style: const TextStyle(color: Colors.white),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: gramController,
              keyboardType: TextInputType.number,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(
                labelText: 'Grams',
                labelStyle: TextStyle(color: Colors.white70),
                enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.white30),
                ),
                focusedBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.redAccent),
                ),
              ),
            ),
            const SizedBox(height: 10),
            Text(
              "Per 100g: ${food['nutriments']?['energy-kcal_100g']?.toString() ?? 'N/A'} kcal",
              style: const TextStyle(color: Colors.white70, fontSize: 12),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Cancel", style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.redAccent,
            ),
            onPressed: () async {
              final gramsText = gramController.text.trim();
              if (gramsText.isEmpty) {
                TrenAlerts.error(context, "Please enter grams");
                return;
              }
              
              int grams = int.tryParse(gramsText) ?? 0;
              if (grams <= 0) {
                TrenAlerts.error(context, "Please enter a valid amount");
                return;
              }
              
              double kcalPer100g = double.tryParse(
                food['nutriments']?['energy-kcal_100g']?.toString() ?? '0',
              ) ?? 0;
              
              if (kcalPer100g <= 0) {
                TrenAlerts.error(context, "Calorie information not available");
                return;
              }
              
              double totalKcal = (kcalPer100g * grams) / 100;
              int totalKcalInt = totalKcal.round();
              
              // Add calories to the database
              await widget.onAddCalories(totalKcalInt);
              
              Navigator.pop(context);
            },
            child: const Text("Add", style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  Widget _buildFoodCard(dynamic food) {
    final nutriments = food['nutriments'] ?? {};
    final productName = food['product_name'] ?? 'Unknown Product';
    final imageUrl = food['image_front_thumb_url'];
    
    return Card(
      color: const Color(0xFF2A2A2A),
      margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 12),
      child: ListTile(
        leading: imageUrl != null
            ? ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.network(
                  imageUrl,
                  width: 50,
                  height: 50,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) {
                    return const Icon(Icons.fastfood, color: Colors.white);
                  },
                ),
              )
            : const Icon(Icons.fastfood, color: Colors.white),
        title: Text(
          productName,
          style: const TextStyle(color: Colors.white),
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
        ),
        subtitle: Text(
          "Kcal: ${nutriments['energy-kcal_100g']?.toString() ?? 'N/A'} | "
          "P: ${nutriments['proteins_100g']?.toString() ?? 'N/A'}g | "
          "C: ${nutriments['carbohydrates_100g']?.toString() ?? 'N/A'}g | "
          "F: ${nutriments['fat_100g']?.toString() ?? 'N/A'}g",
          style: const TextStyle(color: Colors.white70, fontSize: 13),
        ),
        trailing: IconButton(
          icon: const Icon(Icons.add_circle, color: Colors.redAccent),
          onPressed: () => _showGramPopup(food),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeV2(
      child: Column(
        children: [
          const SizedBox(height: 20),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: TextField(
              controller: _searchController,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: 'Search for food...',
                hintStyle: const TextStyle(color: Colors.white38),
                filled: true,
                fillColor: const Color(0xFF2A2A2A),
                prefixIcon: const Icon(Icons.search, color: Colors.white),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear, color: Colors.white),
                        onPressed: () {
                          _searchController.clear();
                          setState(() => _foods = []);
                        },
                      )
                    : null,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
              onChanged: (val) {
                if (val.trim().length >= 3) {
                  searchFoods(val.trim());
                } else {
                  setState(() => _foods = []);
                }
              },
            ),
          ),
          const SizedBox(height: 10),
          Expanded(
            child: _isLoading
                ? const Center(
                    child: CircularProgressIndicator(color: Colors.redAccent),
                  )
                : _foods.isEmpty
                    ? Center(
                        child: Text(
                          _searchController.text.trim().length < 3
                              ? "Type at least 3 characters to search"
                              : "No food found.",
                          style: const TextStyle(color: Colors.white54, fontSize: 16),
                        ),
                      )
                    : ListView.builder(
                        itemCount: _foods.length,
                        itemBuilder: (ctx, index) => _buildFoodCard(_foods[index]),
                      ),
          ),
        ],
      ),
    );
  }
}

class AICoachPage extends StatelessWidget {
  const AICoachPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const SafeV2(
      child: Center(
        child: Text(
          'Incoming ...',
          style: TextStyle(color: Colors.white, fontSize: 20),
        ),
      ),
    );
  }
}
